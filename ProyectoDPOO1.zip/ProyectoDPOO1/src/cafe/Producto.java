package cafe;

public class Producto {
	
	protected String nombre ;
	protected float precio ;

}
